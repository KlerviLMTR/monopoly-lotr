package fr.ut1.rtai.monopoly.cases;

import fr.ut1.rtai.monopoly.Joueur;

public class CasePrison extends Case {

	public CasePrison() {
		super("Case Prison");
	}

	@Override
	public void actionCase(Joueur j) {
		
	}

}