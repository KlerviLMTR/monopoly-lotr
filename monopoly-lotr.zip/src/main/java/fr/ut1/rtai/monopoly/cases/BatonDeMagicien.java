package fr.ut1.rtai.monopoly.cases;

import fr.ut1.rtai.monopoly.Joueur;

public class BatonDeMagicien extends CasePropriete {

	public BatonDeMagicien(String nom, int coutAchat, int valHyp) {
		super(nom, coutAchat, valHyp);
	}

	@Override
	public void actionCase(Joueur j) {
		// TODO Auto-generated method stub
		
	}

}
