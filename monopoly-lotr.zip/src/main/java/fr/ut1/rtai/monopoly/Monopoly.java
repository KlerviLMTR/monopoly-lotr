package fr.ut1.rtai.monopoly;

public class Monopoly {

}
