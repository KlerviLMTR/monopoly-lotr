package fr.ut1.rtai.monopoly.cases;

import fr.ut1.rtai.monopoly.Joueur;

public class CaseEvenement extends Case {

    public CaseEvenement() {
        super("Case évenement");
        // TODO Auto-generated constructor stub
    }

	@Override
	public void actionCase(Joueur j) {
		// TODO Auto-generated method stub
		
	}

}
