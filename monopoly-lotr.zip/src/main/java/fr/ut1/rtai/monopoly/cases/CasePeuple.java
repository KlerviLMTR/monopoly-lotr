package fr.ut1.rtai.monopoly.cases;

import fr.ut1.rtai.monopoly.Joueur;

public class CasePeuple extends Case {

    public CasePeuple() {
        super("Case peuple");
    }

	@Override
	public void actionCase(Joueur j) {
		
	}

}
