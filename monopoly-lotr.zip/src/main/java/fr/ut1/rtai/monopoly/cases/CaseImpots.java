package fr.ut1.rtai.monopoly.cases;

import fr.ut1.rtai.monopoly.Joueur;

public class CaseImpots extends Case {

	private String description;
	public CaseImpots(String description) {
		super("Case Impôts");
		this.description=description;
	}

	@Override
	public void actionCase(Joueur j) {
		// TODO Auto-generated method stub
		
	}

}
