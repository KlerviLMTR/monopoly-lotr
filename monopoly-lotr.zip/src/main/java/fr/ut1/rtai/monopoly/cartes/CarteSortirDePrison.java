package fr.ut1.rtai.monopoly.cartes;

public class CarteSortirDePrison extends Carte {

	public CarteSortirDePrison(String titre, String description) {
		super(titre, description);
		// TODO Auto-generated constructor stub
	}

}
