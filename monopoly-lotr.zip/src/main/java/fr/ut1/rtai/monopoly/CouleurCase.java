package fr.ut1.rtai.monopoly;

public enum CouleurCase {
	violet, blanc, rose, orange, rouge, jaune, vert, bleu
}
