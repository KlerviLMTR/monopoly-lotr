package fr.ut1.rtai.monopoly;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PlateauTest {

	private Plateau p;
	@Before
	public void setUp() throws Exception {
		this.p = new Plateau();
	}

	@After
	public void tearDown() throws Exception {
		this.p=null;
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
