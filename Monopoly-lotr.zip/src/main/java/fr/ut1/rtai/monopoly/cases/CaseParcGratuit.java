package fr.ut1.rtai.monopoly.cases;

import fr.ut1.rtai.monopoly.Joueur;

public class CaseParcGratuit extends Case {
	public CaseParcGratuit() {
		super("Case parc gratuit");

	}

	@Override
	public void actionCase(Joueur j) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void afficherCase() throws InterruptedException {
		// TODO Auto-generated method stub
		
	}

}
