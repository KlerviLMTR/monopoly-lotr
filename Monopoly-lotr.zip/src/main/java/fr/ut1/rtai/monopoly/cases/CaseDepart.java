package fr.ut1.rtai.monopoly.cases;

import fr.ut1.rtai.monopoly.Joueur;

public class CaseDepart extends Case {

	public CaseDepart() {
		super("Case départ");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void actionCase(Joueur j) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void afficherCase() throws InterruptedException {
		// TODO Auto-generated method stub
		
	}

}
