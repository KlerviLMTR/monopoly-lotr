package fr.ut1.rtai.monopoly;

public enum ECouleurCase {
	violet, blanc, rose, orange, rouge, jaune, vert, bleu
}
